import c4d
import os

fn = os.path.join(os.path.dirname(__file__), 'DP Decal Tool')
def main():

    c4d.documents.MergeDocument(doc, fn, c4d.SCENEFILTER_MATERIALS | c4d.SCENEFILTER_OBJECTS)
    c4d.EventAdd()

if __name__=='__main__':
    main()