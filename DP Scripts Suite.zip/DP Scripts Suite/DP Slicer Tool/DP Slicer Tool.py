""" 
    Copyright: DP
    Author: Dimona Patrick
    Year: 2024
    Description: This script help to slice object 
    Use this script at your own risk
"""
import c4d
import os

fn = os.path.join(os.path.dirname(__file__), 'DP Slicer Tool')
def main():

    c4d.documents.MergeDocument(doc, fn, c4d.SCENEFILTER_MATERIALS | c4d.SCENEFILTER_OBJECTS)
    c4d.EventAdd()

if __name__=='__main__':
    main()